package com.example.inventory_service_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServiceTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
